﻿public abstract class Felime : Mammal
{
    protected Felime(string animalName, double animalwiegth, string livingRegion) 
        :base(animalName, animalwiegth, livingRegion)
    { }
}