﻿public abstract class Mammal : Animal
{
    protected Mammal(string animalName, double animalwiegth, string livingRegion) 
        :base(animalName, animalwiegth, livingRegion)
    { }
}